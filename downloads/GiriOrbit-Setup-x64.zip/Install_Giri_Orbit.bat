@echo off
title Installing Giri Orbit Sovereign Suite (Native C++) - Made by Abhinav Giri
color 0b
echo =====================================================================
echo  GIRI ORBIT SOVEREIGN PC SUITE - ONE-CLICK SAFE INSTALLER
echo  Made by Abhinav Giri (GitHub: @abhinavgiri45 ^| Instagram: @abhinavgiri45)
echo  100%% Offline Standalone Native C++ Desktop Architecture
echo  Zero Cloudflare Verification ^| Zero Telemetry ^| Zero Browser Engines
echo =====================================================================
echo.
echo [1/3] Unblocking downloaded files from Windows SmartScreen filter...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File -ErrorAction SilentlyContinue"

echo [2/3] Trusting Abhinav Giri Authenticode Code Signing Certificate...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=(Get-AuthenticodeSignature '%~dp0Setup.exe').SignerCertificate; if($c){ $s=New-Object System.Security.Cryptography.X509Certificates.X509Store('TrustedPublisher','CurrentUser'); $s.Open('ReadWrite'); $s.Add($c); $s.Close() }" >nul 2>&1

echo [3/3] Launching Giri Orbit Sovereign Setup Wizard...
start "" "%~dp0Setup.exe"
exit
